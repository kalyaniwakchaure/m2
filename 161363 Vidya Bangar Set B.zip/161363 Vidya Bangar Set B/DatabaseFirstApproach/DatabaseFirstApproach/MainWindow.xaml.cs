﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using static DatabaseFirstApproach.ServiceCenter;

namespace DatabaseFirstApproach
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
   
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public string ConStr = @"data source = ndamssql\sqlilearn; user id=sqluser; password=sqluser;initial catalog =Training_19Sep18_Pune";

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            cmbData.Items.Clear();
            foreach (var item in Enum.GetValues(typeof(DeviceTypes)))
            {
                cmbData.Items.Add(item);
            }
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string value = cmbData.SelectedValue.ToString();
            SqlConnection con = new SqlConnection(ConStr);
            DataTable dt = new DataTable();
            SqlCommand com = new SqlCommand("Vidya_Lenovo.uspSearchServiceCenter", con);
            com.Parameters.AddWithValue("@s", value);
            com.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            if (dr.HasRows)
            {
                dt.Load(dr);
                dgData.ItemsSource = dt.DefaultView;
            }
            else
                MessageBox.Show("no values found");

            con.Close();
        }
    }
}
