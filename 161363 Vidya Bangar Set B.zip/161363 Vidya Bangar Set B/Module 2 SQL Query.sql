use Training_19Sep18_Pune

create Schema Vidya_Lenovo

create table Vidya_Lenovo.ServiceCenter
(
ServiceID varchar(6) primary key,
SDate datetime not null,
OwnerName varchar(25) not null,
Contact int not null,
DeviceType varchar(20) not null,
SerialNo varchar(20) not null,
IssueDescription varchar(20)
)

alter table Vidya_Lenovo.ServiceCenter alter column Contact bigint

sp_help Vidya_Lenovo.ServiceCenter

-------: Store Procedure for add service :-------
alter proc Vidya_Lenovo.uspAddService
(
@sid varchar(6),
@sdate datetime,
@oname varchar(25),
@cont bigint,
@dtype varchar(20),
@sno varchar(20),
@idescr varchar(20)
)
as
begin
	insert into Vidya_Lenovo.ServiceCenter
	values(@sid,@sdate,@oname,@cont,@dtype,@sno,@idescr)
end


------: Store Procedure for getting service details :--------
create proc Vidya_Lenovo.uspGetServices
as
begin
	select * from Vidya_Lenovo.ServiceCenter
end

delete from Vidya_Lenovo.ServiceCenter





alter proc Vidya_Lenovo.uspSearchServiceCenter
(
@s varchar(6)
)
as
begin
	select * from Vidya_Lenovo.ServiceCenter
	where  DeviceType= @s
end

insert into Vidya_Lenovo.ServiceCenter values('SR1222',26/10/2018,'vidya',9146762674,'Laptop','1111-2222-3333','fdshgfjhdsghz')