use Training_19Sep18_Pune
select * from Vidya_Employee.Employee1

create proc Vidya_Employee.AddEmployee_161363(
@EName varchar(25),
@Address varchar(250),
@sal money,
@nop int,
@pos varchar(20),
@eid int output)

as 
begin
insert into Vidya_Employee.Employee1 values (@EName, @Address,@sal,@nop,@pos)
set @eid = SCOPE_IDENTITY()
end

alter proc Vidya_Employee.GetEmployeeDetails
(
@eid int)
as
begin
select * from Vidya_Employee.Employee1 where EmployeeId = @eid
end


insert into Vidya_Employee.Employee1 values('vvvvv','Pune',81666,2,'Analyst')