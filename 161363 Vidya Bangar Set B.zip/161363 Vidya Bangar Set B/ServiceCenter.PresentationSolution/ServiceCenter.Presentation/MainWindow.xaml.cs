﻿using ServiceCenterBL;
using ServiceCenterEntities;
using ServiceCenterExceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ServiceCenter.Presentation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
           
        }

        private void DatePicker_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            
        }
        ServiceBL sb = new ServiceBL();
        bool validate;
        private void btnSubmitRequest_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string srid = txtServiceID.Text.ToString();
                ServiceBL sb = new ServiceBL();
                validate = sb.ValidateServiceId(srid);
                if (validate == false)
                    MessageBox.Show(" Please Enter Valid Service ID...");

                long c = long.Parse(txtContactNo.Text);
                //// Calling ValidateContact()
                validate = sb.ValidateContact(c);
                if (validate == false)
                    MessageBox.Show(" Please Enter Valid Contact which starts with 7,8 or 9...");

                string sno = txtSerialNo.Text;
                //// Calling ValidateSerialNo()
                validate = sb.ValidateSerialNo(sno);
                if (validate == false)
                    MessageBox.Show("Please Enter serial no in proper format as '1111-2222-3333'");

                if (validate == true)
                {
                    ServiceCenter1 service = new ServiceCenter1();
                    service.ServiceID = txtServiceID.Text;
                    service.Date = Convert.ToDateTime(txtDate.Text);
                    service.OwnerName = txtOwnerName.Text;
                    service.Contact = long.Parse(txtContactNo.Text);
                    service.DeviceType = cmbDevice.SelectedValue.ToString();
                    service.SerialNo = txtSerialNo.Text;
                    service.IssueDescription = txtIssueDescription.Text;

                    int sid = sb.AddService(service);
                    MessageBox.Show(string.Format("New Service Added.\nService Id: {0}", sid),
                        "Service Management System");

                    /////// Displaying Service Details in Data Grid
                    ///
                    
                }
                
            }
            catch (SCExceptions ex)
            {
                MessageBox.Show(ex.Message, "Service Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Service Management System");
            }

        }
            

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            foreach (var item in Enum.GetValues(typeof(DeviceTypes)))
            {
                cmbDevice.Items.Add(item);
            }
            DataTable dt = sb.Display();
            if (dt != null)
            {
                dgDisplay.ItemsSource = dt.DefaultView;
            }
            else
            {
                MessageBox.Show("Table is empty", "Product Management System");
            }
        }

        private void txtServiceID_LostFocus(object sender, RoutedEventArgs e)
        {
        }

        private void txtDate_LostFocus(object sender, RoutedEventArgs e)
        {
        }

        private void txtContactNo_LostFocus(object sender, RoutedEventArgs e)
        {
        }

        private void txtSerialNo_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void txtSerialNo_LostFocus(object sender, RoutedEventArgs e)
        {
        }
    }
}
