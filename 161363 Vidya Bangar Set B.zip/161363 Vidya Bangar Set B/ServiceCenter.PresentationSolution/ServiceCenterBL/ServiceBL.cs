﻿using ServiceCenterDAL;
using ServiceCenterEntities;
using ServiceCenterExceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceCenterBL
{
    public class ServiceBL
    {
        public int AddService(ServiceCenter1 service)
        {
            try
            {
                ServiceDAL pd = new ServiceDAL();
                return pd.AddEmployee(service);
            }
            catch (SCExceptions)
            {
                throw;
            }
        }
        public DataTable Display()
        {
            try
            {
                ServiceDAL pd = new ServiceDAL();
                return pd.DisplayServices();
            }
            catch (SCExceptions)
            {
                throw;
            }
        }

        //===================Validating Service ID=======================
        public bool ValidateServiceId(string sid)
        {
            bool validServiceId = false;
            if (sid.Length == 6 && sid.StartsWith("SR") && sid!=string.Empty)
                validServiceId = true;
            return validServiceId;
        }

        //===================Validating Contact No=======================
        public bool ValidateContact(long contact)
        {
            bool validContact = false;
            if (!System.Text.RegularExpressions.Regex.IsMatch(contact.ToString(), @"[^0-9]$"))
            {
                validContact = true;
            }

            if (!System.Text.RegularExpressions.Regex.IsMatch(contact.ToString(), @"^([789]\d{10}|[0-7]\d*)$"))
            {
                validContact = true;
            }
            return validContact;
        }

        //===================Validating Date as Current Date=======================
        public bool ValidateDate(DateTime dt)
        {
            bool validDate = false;
            if (dt == DateTime.Now)
            {
                validDate = true;
            }
            return validDate;
        }

        //===================Validating Serial No=======================
        public bool ValidateSerialNo(string sno)
        {
            bool validSNo = false;
            if (sno.ElementAt(4).Equals('-') && sno.ElementAt(9).Equals('-'))
                validSNo = true;
            return validSNo;
        }
    }
}
