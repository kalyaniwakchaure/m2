﻿using ServiceCenterEntities;
using ServiceCenterExceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceCenterDAL
{
    public class ServiceDAL
    {
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;



        static ServiceDAL()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public ServiceDAL()
        {
            con = new SqlConnection(conStr);

        }
        public int AddEmployee(ServiceCenter1 sc1)
        {
            int sid = 0;
            try
            {
                //con = new SqlConnection();
                //con.ConnectionString = conStr; 
                cmd = new SqlCommand();
                cmd.CommandText = "Vidya_Lenovo.uspAddService";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                //cmd.Parameters.Add("@sId", SqlDbType.Int);
                //cmd.Parameters["@sId"].Direction = ParameterDirection.Output;


                cmd.Parameters.AddWithValue("@sid", sc1.ServiceID);
                cmd.Parameters.AddWithValue("@sdate", sc1.Date);
                cmd.Parameters.AddWithValue("@oname", sc1.OwnerName);
                cmd.Parameters.AddWithValue("@cont", sc1.Contact);
                cmd.Parameters.AddWithValue("@dtype", sc1.DeviceType);
                cmd.Parameters.AddWithValue("@sno", sc1.SerialNo);
                cmd.Parameters.AddWithValue("@idescr", sc1.IssueDescription);

                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (SCExceptions) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return sid;
        }
        //// Fetching Service Details from Database
        public DataTable DisplayServices()
        {
            DataTable dt = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "Vidya_Lenovo.uspGetServices";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (SCExceptions) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
    }
}
