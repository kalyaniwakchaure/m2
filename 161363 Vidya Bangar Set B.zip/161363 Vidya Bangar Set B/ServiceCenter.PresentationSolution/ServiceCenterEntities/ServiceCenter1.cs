﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceCenterEntities
{
    public class ServiceCenter1
    {
        //===== : ServiceCenter Class Properties
        public string ServiceID { get; set; }
        public DateTime Date { get; set; }
        public string OwnerName { get; set; }
        public long Contact { get; set; }
        public string DeviceType { get; set; }
        public string SerialNo { get; set; }
        public string IssueDescription { get; set; }
    }
    //===== : Enum for Device Type: Laptop,Mobile,Desktop
    public enum DeviceTypes
    {
        Laptop, 
        Mobile,
        Desktop
    }
}
