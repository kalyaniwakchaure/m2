﻿using System;
using System.Runtime.Serialization;

namespace ServiceCenterExceptions
{
    [Serializable]
    public class SCExceptions : Exception
    {
        public SCExceptions()
        {
        }

        public SCExceptions(string message) : base(message)
        {
        }

        public SCExceptions(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected SCExceptions(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}